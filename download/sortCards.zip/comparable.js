class Comparable {
  compareTo(obj) {
    return null
  }
}
module.exports = Comparable
