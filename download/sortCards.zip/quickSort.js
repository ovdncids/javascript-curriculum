function quickSort(list, order) {
  //console.log(list)
  let n = list.length
  if (n < 2) return list

  let list1 = []
  let list2 = []
  let listEq = []

  let pivot = list[0]

  for (let i = 0; i < list.length; ++i) {
    const rankPivot = (pivot.fiveCards[order].rank + 11) % 13 + 2
    const rankList = (list[i].fiveCards[order].rank + 11) % 13 + 2
    if (rankList < rankPivot) {
      list1.push(list[i])
    } else if (rankList === rankPivot) {
      listEq.push(list[i])
    } else {
      list2.push(list[i])
    }
  }

  let res = [].concat(quickSort(list1, order)).concat(listEq).concat(quickSort(list2, order))

  return res
}

module.exports = quickSort
